export default class SearchBar {

    


    constructor(selector,callbacks) {
        this.input = document.querySelector(selector);
        this.callbacks = callbacks; 
        this.isSearched = false;
        this.searchText = "";
       
    }

    
    setInput =(value) =>{
        this.input.value = value
        this.searchText = `${value}`
    } 

    init() {

   
  

    
        const setListeners = () =>{
            const checkInput = () => {
                
                if ( this.input.value == "" || this.input.value.trim() === '') {
                    this.input.classList.add('blinking-border');
                    this.input.style.borderLeft = '2px solid rgb(128,128,128,1)';
                } else {
                    this.input.classList.remove('blinking-border');
                    this.input.style.borderLeft = 'none';
                }
                
            }


            const handleInputChange = () => {
                const callBackInputChange = async (callback) =>{
                    if(!this.isSearched){
                        this.isSearched = true;
                        try {
                            await callback()
                        } catch (error) {
                        } finally {
                            this.isSearched = false;
                        }
                    }
                }
                this.searchText = this.input.value;
                callBackInputChange(this.callbacks.onChange);
            }
            checkInput();
            this.input.addEventListener('input', checkInput.bind(this));
            this.input.addEventListener('change', checkInput.bind(this));
            this.input.addEventListener('input', handleInputChange.bind(this));
        }


        setListeners();


    }



   


   

  
    




 
}

