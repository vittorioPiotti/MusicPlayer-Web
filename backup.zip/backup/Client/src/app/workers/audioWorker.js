
let terminated = false;

self.onmessage = function(e) {
    if (e.data === 'terminate') {
        terminated = true;
        self.close();
        return;
    }
    if (terminated) return;

    const { url, index } = e.data;

    fetch(url)
        .then(response => response.arrayBuffer())
        .then(arrayBuffer => {
            if (terminated) return;
            self.postMessage({ index, arrayBuffer });
        })
        .catch(e => {
            if (terminated) return;
            self.postMessage({ index, error: e.message });
        });
};
