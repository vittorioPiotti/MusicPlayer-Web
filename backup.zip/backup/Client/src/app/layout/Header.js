export default class Header{
    
    constructor(id){
        this.id = id
    }
    

    init = () =>  {
        document.getElementById(this.id).innerHTML = this.innerHTML();
    }


    innerHTML = () => `
        <div class="brand-container">
            <div class="brand">Music Player</div>
        </div>
    `;
    

    
  
    
     
}

