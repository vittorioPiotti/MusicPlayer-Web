export default class Animations {

    static fade(element, callback) {
        if (element) {
            if (!element.classList.contains('fadeOut')) {
                element.classList.add('fadeOut');
            }
            if (element.classList.contains('fadeIn')) {
                element.classList.remove('fadeIn');
            }
            setTimeout(function() {
                callback();
                if (element.classList.contains('fadeOut')) {
                    element.classList.remove('fadeOut');
                }
                if (!element.classList.contains('fadeIn')) {
                    element.classList.add('fadeIn');
                }
            }, 300);
        }
    }

    static fadeOut(timer,element,callback){
        element.classList.add('tooltip-visible');
        if (!element.classList.contains('fadeIn')) {
            element.classList.add('fadeIn');
        }
        if (element.classList.contains('fadeOut')) {
            element.classList.remove('fadeOut');
        }
        setTimeout(() => {
            if (!element.classList.contains('fadeOut')) {
                element.classList.add('fadeOut');
            }
            if (element.classList.contains('fadeIn')) {
                element.classList.remove('fadeIn');
            }
        }, timer); 
    }

    static fadeDouble(elementFirst, elementSecond, callback) {
        const elements = [elementFirst, elementSecond];
        elements.forEach(element => {
            if (element) {
                if (!element.classList.contains('fadeOut')) {
                    element.classList.add('fadeOut');
                }
                if (element.classList.contains('fadeIn')) {
                    element.classList.remove('fadeIn');
                }
            }
        });
        setTimeout(function() {
            callback(); 
            elements.forEach(element => {
                if (element.classList.contains('fadeOut')) {
                    element.classList.remove('fadeOut');
                }
                if (!element.classList.contains('fadeIn')) {
                    element.classList.add('fadeIn');
                }
            });
        }, 300);
    }
    

    static fadeCustomTimer(timer, element, callback) {
        if (element) {
            if (!element.classList.contains('fadeOut')) {
                element.classList.add('fadeOut');
            }
            if (element.classList.contains('fadeIn')) {
                element.classList.remove('fadeIn');
            }
            setTimeout(function() {
                callback();
                if (element.classList.contains('fadeOut')) {
                    element.classList.remove('fadeOut');
                }
                if (!element.classList.contains('fadeIn')) {
                    element.classList.add('fadeIn');
                }
            }, timer);
        }
    }

}


