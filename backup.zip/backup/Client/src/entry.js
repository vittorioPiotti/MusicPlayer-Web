import App from './app/App.js';

fetch('./config/json.php')
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            console.error('Error:', data.error);
            return;
        }
        const theme = data.theme;
        document.body.setAttribute('data-theme', theme);
        const favicon = document.createElement('link');
        favicon.rel = 'icon';
        favicon.type = 'image/png';
        favicon.href = `./assets/images/favicon-${theme}.png`;        
        document.head.appendChild(favicon);
        const app = new App(data.page, data.musicId, data.albumId, data.idArtist, data.idMusic,"home");
        app.init();
    })
    .catch(error => console.error('Fetch error:', error));
